
import java.util.ArrayList;

public class Alunos {

    private String nome;
    private String CodTurm;
    private String matricula;
    int quantidade;
    ArrayList<Alunos> ListaAlunos;// criando uma ArrayList(Vetor aprimorado), serve para guardar dados de um objeto
    
    
    public Alunos(String nome, String CodTurm, String matricula) { //construtor com parâmetro
        this.nome = nome;
        this.CodTurm = CodTurm;
        this.matricula = matricula;
        ListaAlunos = new ArrayList(); // inicializando a ArrayList
        
    }
    public Alunos(){ //Construtor simples sem parâmetro
        ListaAlunos = new ArrayList(); // devemos inicializar nos dois construtores
    }
    
    public void ListarAluno(Alunos A){ // Método que vai add um objeto na ArrayList, recebe um objeto como parâmetro
        ListaAlunos.add(A);
        
    }
    
    public ArrayList<Alunos> getListaAlunos() {
        return ListaAlunos;
    }

    //Métodos get's e set's
    public void setListaAlunos(ArrayList<Alunos> ListaAlunos) {    
        this.ListaAlunos = ListaAlunos;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCodTurm() {
        return CodTurm;
    }

    public void setCodTurm(String CodTurm) {
        this.CodTurm = CodTurm;
    }

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }
    
    
    
}
