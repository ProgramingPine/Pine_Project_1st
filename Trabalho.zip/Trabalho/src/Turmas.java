
import java.util.ArrayList;


public class Turmas {
    
    private String codTurma;
    private String curso;
    private ArrayList<Turmas> ListaDeTurmas;// criando uma ArrayList para add os dados do objeto
    
    public Turmas(String codTurma, String curso) { // construtor com parâmetro
        this.codTurma = codTurma;
        this.curso = curso;
        ListaDeTurmas = new ArrayList(); // inicializando a ArrayList
    }

    public Turmas(){ // construtor simples sem parâmetro
     ListaDeTurmas = new ArrayList();   
    }
    
    public void addTruma(Turmas T){ // método que vai pegar um objeto e guardar na ArrayList
        
    }
    
    //métodos get's e set's

    public String getCodTurma() {
        return codTurma;
    }

    public void setCodTurma(String codTurma) {
        this.codTurma = codTurma;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

    public ArrayList<Turmas> getListaDeTurmas() {
        return ListaDeTurmas;
    }

    public void setListaDeTurmas(ArrayList<Turmas> ListaDeTurmas) {
        this.ListaDeTurmas = ListaDeTurmas;
    }
    
    
    
}
