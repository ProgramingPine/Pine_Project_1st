
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;


public class CadastroTurmas extends javax.swing.JFrame {
    
    ArrayList<Turmas> ListaDeTurmas = new ArrayList(); // ArrayList criada da classe turmas
    String modo;
    
   public CadastroTurmas() { // Construtor
        initComponents();
        setLocationRelativeTo(null);// para aparecer no centro da tela
        setResizable(false); // para nao ser maximizada
        setTitle("Cadastro de Turmas"); //`Título da Jframe
        modo = "Inicio";
        ManipulaInterface();
    }
    
    public void CarregaTabela(){ // método para manipular a tabela
        DefaultTableModel modelo = new DefaultTableModel(new Object[]{"Curso","Código da turma"},0);
        for (int i = 0; i < ListaDeTurmas.size(); i++) {
            Object linha[] = new Object[]{ListaDeTurmas.get(i).getCurso(),
                                          ListaDeTurmas.get(i).getCodTurma()};
            modelo.addRow(linha);
        }
                tbl_turmas.setModel(modelo);
                txtCodTurma.setText(""); // Vai ser limpo o campo de texto toda vez que o´método for chamado
                txtCursoTurma.setText(""); // se aplica para esse campo de texto também
    }
    public void ManipulaInterface(){
        switch(modo){
            case "Inicio":
                btnNovo.setEnabled(true);
                btnCadastrar.setEnabled(false);
                btnExcluir.setEnabled(false);
                btnEditar.setEnabled(false);
                txtCodTurma.setEnabled(false);
                txtCursoTurma.setEnabled(false);
                break;
            case "Novo":
                btnNovo.setEnabled(false);
                btnCadastrar.setEnabled(true);
                btnExcluir.setEnabled(true);
                btnEditar.setEnabled(true);
                txtCodTurma.setEnabled(true);
                txtCursoTurma.setEnabled(true);
                break;
            case "Cadastrar":
                btnNovo.setEnabled(true);
                btnCadastrar.setEnabled(false);
                btnExcluir.setEnabled(false);
                btnEditar.setEnabled(false);
                txtCodTurma.setEnabled(false);
                txtCursoTurma.setEnabled(false);
                break;
            case "Editar":
                btnNovo.setEnabled(false);
                btnCadastrar.setEnabled(true);
                btnExcluir.setEnabled(true);
                btnEditar.setEnabled(false);
                txtCodTurma.setEnabled(true);
                txtCursoTurma.setEnabled(true);
                break;
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtCodTurma = new javax.swing.JTextField();
        txtCursoTurma = new javax.swing.JTextField();
        btnCadastrar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_turmas = new javax.swing.JTable();
        btnFechar = new javax.swing.JButton();
        btnExcluir = new javax.swing.JButton();
        btnEditar = new javax.swing.JButton();
        btnNovo = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Código da Turma:");

        jLabel2.setText("Curso");

        btnCadastrar.setText("Cadastrar");
        btnCadastrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCadastrarActionPerformed(evt);
            }
        });

        tbl_turmas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Curso", "Código da Turma"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tbl_turmas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_turmasMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tbl_turmas);
        if (tbl_turmas.getColumnModel().getColumnCount() > 0) {
            tbl_turmas.getColumnModel().getColumn(0).setResizable(false);
            tbl_turmas.getColumnModel().getColumn(1).setResizable(false);
        }

        btnFechar.setText("Fechar");
        btnFechar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFecharActionPerformed(evt);
            }
        });

        btnExcluir.setText("Excluir");
        btnExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExcluirActionPerformed(evt);
            }
        });

        btnEditar.setText("Editar");
        btnEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarActionPerformed(evt);
            }
        });

        btnNovo.setText("Novo");
        btnNovo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNovoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btnNovo)
                        .addGap(28, 28, 28)
                        .addComponent(btnFechar)
                        .addGap(18, 18, 18)
                        .addComponent(btnCadastrar))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel1)
                                .addComponent(jLabel2))
                            .addGap(18, 18, 18)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(txtCursoTurma, javax.swing.GroupLayout.DEFAULT_SIZE, 330, Short.MAX_VALUE)
                                .addComponent(txtCodTurma)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnEditar)
                .addGap(18, 18, 18)
                .addComponent(btnExcluir)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtCodTurma, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtCursoTurma, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnCadastrar)
                    .addComponent(btnFechar)
                    .addComponent(btnNovo))
                .addGap(31, 31, 31)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 217, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnExcluir)
                    .addComponent(btnEditar))
                .addContainerGap(18, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 51, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnCadastrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCadastrarActionPerformed
      // Botão cadastrar
      
        if (modo.equals("Novo")) {
            Turmas T = new Turmas(txtCursoTurma.getText(), txtCodTurma.getText()); //vai ser criado um objeto da classe Turmas
        ListaDeTurmas.add(T); // vai ser adicionado o objeto na ArrayList criada nessa classe
        }else if  (modo.equals("Editar")){
             int index = tbl_turmas.getSelectedRow();
             ListaDeTurmas.get(index).setCurso(txtCursoTurma.getText());
             ListaDeTurmas.get(index).setCodTurma(txtCodTurma.getText());
        }
        CarregaTabela();// chamamos o método que manipula a tabela para poder ser atualizada na Jframe
        modo = "Inicio";
        ManipulaInterface();
    }//GEN-LAST:event_btnCadastrarActionPerformed

    private void btnFecharActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFecharActionPerformed
        setVisible(false);
    }//GEN-LAST:event_btnFecharActionPerformed

    private void tbl_turmasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_turmasMouseClicked
        
        int index = tbl_turmas.getSelectedRow(); // vai transformar em um index
        if (index >= 0 && index < ListaDeTurmas.size()) {
            Turmas T = ListaDeTurmas.get(index); // vai pegar o objeto que está na linha selecionada
            txtCodTurma.setText(T.getCodTurma());
            txtCursoTurma.setText(T.getCurso());
        }
    }//GEN-LAST:event_tbl_turmasMouseClicked

    private void btnExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExcluirActionPerformed
        int index = tbl_turmas.getSelectedRow(); // vai ser um índice da linha selecionada
        if (index >=0 && index < ListaDeTurmas.size()) {
            ListaDeTurmas.remove(index);
        }
        CarregaTabela();
    }//GEN-LAST:event_btnExcluirActionPerformed

    private void btnEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarActionPerformed
        modo = "Editar";
        ManipulaInterface();
    }//GEN-LAST:event_btnEditarActionPerformed

    private void btnNovoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNovoActionPerformed
        modo = "Novo";
        ManipulaInterface();
    }//GEN-LAST:event_btnNovoActionPerformed

    public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CadastroTurmas().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCadastrar;
    private javax.swing.JButton btnEditar;
    private javax.swing.JButton btnExcluir;
    private javax.swing.JButton btnFechar;
    private javax.swing.JButton btnNovo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tbl_turmas;
    private javax.swing.JTextField txtCodTurma;
    private javax.swing.JTextField txtCursoTurma;
    // End of variables declaration//GEN-END:variables
}
