
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class TelaCadastro extends javax.swing.JFrame {
    

 
    ArrayList<Alunos> ListaLaunos = new ArrayList(); //criando uma ArryList da classe Alunos com o nome "ListaAlunos"
    String modo; // Variável global para manipular a nossa interface
   
    public TelaCadastro() { // construtor 
        initComponents();
        setLocationRelativeTo(null); // vai fazer a janela aparecer no centro da tela
        modo = "Navegar";
        ManipulaInterface(); // vai fazer a janela ser iniciada com tudo bloqueado exceto o botão "Novo"
        setTitle("Cadastro de Alunos"); // Título da Janela
        setResizable(false);
    }
    public void carregaTabela(){ // método para manipular a tabela
        DefaultTableModel modelo = new DefaultTableModel(new Object[]{"Nome","Matrícula","Código da Turma"},0); //cria o modelo ta tabela
                                                                                       // passamos como parâmetro o nome das colunas
        for (int i = 0; i < ListaLaunos.size(); i++){
            Object linha[] = new Object[]{ListaLaunos.get(i).getNome(),
                                          ListaLaunos.get(i).getMatricula(),
                                          ListaLaunos.get(i).getCodTurm()};
            modelo.addRow(linha);
        }
        tblDados_Alunos.setModel(modelo); // adicionamos o modelo criado a cima na tabela 
        txtCodTurma.setText("");// os campos "Código da turma" vão ser limpos após a chamada dessa função
        txtMatricula.setText("");//  se aplica nesse campo de texto também 
        txtNome.setText(""); // nesse também
    }
    public void ManipulaInterface(){// Método para manipular os botões, pra ver quem vai ser liberado e bloqueado e etc
        switch(modo){
            case "Salvar": 
              btnNovo.setEnabled(true);
              btnEditar.setEnabled(false);
              btnExcluir.setEnabled(false);
              btnSalvar.setEnabled(false);
              txtCodTurma.setEnabled(false);
              txtMatricula.setEnabled(false);
              txtNome.setEnabled(false);
                break;
            case "Novo":
                btnEditar.setEnabled(false);
                btnExcluir.setEnabled(false);
                btnNovo.setEnabled(false);
                btnSalvar.setEnabled(true);
                txtCodTurma.setEnabled(true);
                txtMatricula.setEnabled(true);
                txtNome.setEnabled(true);
                break;
            case "Navegar":
                btnEditar.setEnabled(false);
                btnExcluir.setEnabled(false);
                btnSalvar.setEnabled(false);
                btnNovo.setEnabled(true);
                txtCodTurma.setEnabled(false);
                txtMatricula.setEnabled(false);
                txtNome.setEnabled(false);
                break;
            case "Selecao":
                btnEditar.setEnabled(true);
                btnExcluir.setEnabled(true);
                btnNovo.setEnabled(true);
                btnSalvar.setEnabled(false);
                txtCodTurma.setEnabled(false);
                txtMatricula.setEnabled(false);
                txtNome.setEnabled(false);
                break;
            case "Editar":
                btnSalvar.setEnabled(true);
                btnExcluir.setEnabled(false);
                btnEditar.setEnabled(false);
                btnNovo.setEnabled(false);
                txtCodTurma.setEnabled(true);
                txtMatricula.setEnabled(true);
                txtNome.setEnabled(true);
                break;
            default: System.out.println("Modo  não encontrado");
              
                
        }
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtNome = new javax.swing.JTextField();
        txtMatricula = new javax.swing.JTextField();
        txtCodTurma = new javax.swing.JTextField();
        btnSalvar = new javax.swing.JButton();
        btnNovo = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblDados_Alunos = new javax.swing.JTable();
        btnEditar = new javax.swing.JButton();
        btnExcluir = new javax.swing.JButton();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        btnVerificaAluno = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Nome: ");

        jLabel2.setText("Matrícula: ");

        jLabel3.setText("Código da Turma: ");

        btnSalvar.setText("Salvar");
        btnSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalvarActionPerformed(evt);
            }
        });

        btnNovo.setText("Novo");
        btnNovo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNovoActionPerformed(evt);
            }
        });

        tblDados_Alunos.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        tblDados_Alunos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nome", "Matrícula", "CodTurma"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblDados_Alunos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblDados_AlunosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblDados_Alunos);
        if (tblDados_Alunos.getColumnModel().getColumnCount() > 0) {
            tblDados_Alunos.getColumnModel().getColumn(0).setResizable(false);
            tblDados_Alunos.getColumnModel().getColumn(1).setResizable(false);
            tblDados_Alunos.getColumnModel().getColumn(2).setResizable(false);
        }

        btnEditar.setText("Editar");
        btnEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarActionPerformed(evt);
            }
        });

        btnExcluir.setText("Excluir");
        btnExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExcluirActionPerformed(evt);
            }
        });

        btnVerificaAluno.setText("Verificação de ALunos");
        btnVerificaAluno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVerificaAlunoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btnNovo, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnSalvar, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnVerificaAluno)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 506, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnExcluir, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3))
                        .addGap(32, 32, 32)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtNome)
                            .addComponent(txtMatricula)
                            .addComponent(txtCodTurma)))))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtMatricula, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtCodTurma, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSalvar)
                    .addComponent(btnNovo)
                    .addComponent(btnVerificaAluno))
                .addGap(36, 36, 36)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 258, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnEditar)
                    .addComponent(btnExcluir))
                .addContainerGap(31, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 10, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarActionPerformed
        modo = "Editar";
        ManipulaInterface();
    }//GEN-LAST:event_btnEditarActionPerformed

    private void btnSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalvarActionPerformed
            /*Foi feito um teste para poder o sistema entender se o usuário está salvando um dado ou editando*/
            if (modo.equals("Novo")) {
                Alunos A = new Alunos(txtNome.getText(),txtCodTurma.getText(),txtMatricula.getText());
                ListaLaunos.add(A);
            }else if(modo.equals("Editar")){
                int index = tblDados_Alunos.getSelectedRow();
                ListaLaunos.get(index).setNome(txtNome.getText());
                ListaLaunos.get(index).setMatricula(txtMatricula.getText());
                ListaLaunos.get(index).setCodTurm(txtCodTurma.getText());
            }
            carregaTabela();
            modo = "Navegar";
            ManipulaInterface();
           
            
    }//GEN-LAST:event_btnSalvarActionPerformed

    private void btnNovoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNovoActionPerformed
        modo = "Novo";
        ManipulaInterface();
    }//GEN-LAST:event_btnNovoActionPerformed

    private void tblDados_AlunosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblDados_AlunosMouseClicked
      /*foi adicionado um Evento mousecliked, para poder pegar uma linha válida da tabela para assim poder editar ou
        excluir um objeto*/
        int index = tblDados_Alunos.getSelectedRow(); 
        if (index >=0 && index < ListaLaunos.size()) {
            Alunos A = ListaLaunos.get(index);
            txtCodTurma.setText(A.getCodTurm());
            txtMatricula.setText(A.getMatricula());
            txtNome.setText(A.getNome());
            modo = "Selecao";
            ManipulaInterface();
        }
    }//GEN-LAST:event_tblDados_AlunosMouseClicked

    private void btnExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExcluirActionPerformed
        int index = tblDados_Alunos.getSelectedRow(); // cria um índice da linha selecionado
        if (index >=0 && index < ListaLaunos.size()) { // percorre a lista e assim que encontra, o bjeto é removido da Lista
            ListaLaunos.remove(index); // linha que remove o bjeto da linha
        }
        carregaTabela(); // a tabela é recarregada após o ação do botão excluir
        modo = "Navegar";
        ManipulaInterface();
        JOptionPane.showMessageDialog(this, "Excluído com sucesso");
                
    }//GEN-LAST:event_btnExcluirActionPerformed

    private void btnVerificaAlunoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVerificaAlunoActionPerformed
        new CadastroTurmas().setVisible(true);// vai fazer a chamada do Frame Cadastro de Turmas
    }//GEN-LAST:event_btnVerificaAlunoActionPerformed

   
    public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaCadastro().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnEditar;
    private javax.swing.JButton btnExcluir;
    private javax.swing.JButton btnNovo;
    private javax.swing.JButton btnSalvar;
    private javax.swing.JButton btnVerificaAluno;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable tblDados_Alunos;
    private javax.swing.JTextField txtCodTurma;
    private javax.swing.JTextField txtMatricula;
    private javax.swing.JTextField txtNome;
    // End of variables declaration//GEN-END:variables
}
